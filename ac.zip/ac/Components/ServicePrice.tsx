import React from "react";
import { Text, View } from 'react-native';
const ServicePrice = ()=>{
    return(
        <View>
            <Text>ServicePrice</Text>
        </View>

    )
};
export default ServicePrice;