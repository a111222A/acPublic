import React from "react";
import { Text } from "react-native";
import { View } from 'react-native';
const MyVouchers = ()=>{
    return(
        <View>
            <Text>MyVouchers</Text>
        </View>

    )
};
export default MyVouchers;