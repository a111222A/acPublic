import React from "react";
import { Text, View } from 'react-native';
const managePayments = ()=>{
    return(
        <View>
            <Text>managePayments</Text>
        </View>

    )
};
export default managePayments;