import React from "react";
import { Text, View } from 'react-native';
const RegisterComplaint = ()=>{
    return(
        <View>
            <Text>RegisterComplaint</Text>
        </View>

    )
};
export default RegisterComplaint;