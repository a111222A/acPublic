import React from "react";
import { Text, View } from 'react-native';
const Incomplite = ()=>{
    return(
        <View>
            <Text>Incomplite</Text>
        </View>

    )
};
export default Incomplite;