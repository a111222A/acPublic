import React from "react";
import{ View } from 'react-native';

const NewCase = ()=>{
    return(
        <View></View>
    )

}
export default NewCase;